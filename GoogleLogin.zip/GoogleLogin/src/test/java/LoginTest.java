import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.annotations.Title;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import ru.aplana.autotests.pages.BaseTest;
import ru.aplana.autotests.steps.GoogleScenarioSteps;

import java.util.concurrent.TimeUnit;

/**
 * Created by aplana on 24.11.16.
 */
@RunWith(SerenityRunner.class)
public class LoginTest extends BaseTest{


    @Test
    @Title("Проверка авторизации с некорректным логином")
    public void testGoogleLogin() throws Exception {
        googleScenarioSteps.stepGoToLoginGmailPage();
        googleScenarioSteps.stepGmailLogin("test");
        Assert.assertEquals("Получено некорретное сообщение об ошибке", "Не удалось распознать адрес электронной почты.", googleScenarioSteps.stepGetErrorMsg());
    }

}
