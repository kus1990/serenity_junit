import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.annotations.Title;
import net.thucydides.junit.annotations.TestData;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import ru.aplana.autotests.pages.BaseTest;
import ru.aplana.autotests.steps.GoogleScenarioSteps;

import java.util.Arrays;
import java.util.Collection;

/**
 * Created by aplana on 24.11.16.
 */
@RunWith(SerenityParameterizedRunner.class)
public class LoginParametrizedTest extends BaseTest {

    private final String login;

    private final String expectedError;

    public LoginParametrizedTest(String login, String expectedError){
        this.login = login;
        this.expectedError = expectedError;
    }

    @TestData
    public static Collection<Object[]> testData(){
        return Arrays.asList(new Object[][]{
                {"test", "Не удалось распознать адрес электронной почты."},
                {"test1", "Не удалось распознать адрес электронной почты."}
        });
    }

    @Test
    @Title("Проверка авторизации с некорректным логином(с параметризацией)")
    public void testGoogleLoginParametrized() throws Exception {
        googleScenarioSteps.stepGoToLoginGmailPage();
        googleScenarioSteps.stepGmailLogin(this.login);
        Assert.assertEquals("Получено некорретное сообщение об ошибке", this.expectedError, googleScenarioSteps.stepGetErrorMsg());
    }




}
