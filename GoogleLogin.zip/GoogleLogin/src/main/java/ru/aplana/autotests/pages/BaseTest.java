package ru.aplana.autotests.pages;

import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import ru.aplana.autotests.steps.GoogleScenarioSteps;

/**
 * Created by aplana on 24.11.16.
 */
public class BaseTest {
    @Steps
    protected GoogleScenarioSteps googleScenarioSteps;

    @Managed(driver = "firefox")
    WebDriver driver;

    @Before
    public void setUp() throws Exception {
        String workingDir = System.getProperty("user.dir");
        System.setProperty("webdriver.firefox.marionette", workingDir + "\\drivers\\geckodriver.exe");
        String baseUrl = "https://www.google.ru/";
        driver.get(baseUrl);
    }

    @After
    public void tearDown() throws Exception {

    }
}
